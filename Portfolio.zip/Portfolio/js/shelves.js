/* =====================
   STATIC DATA
   ===================== */
const movies = [
  { title: "The Notebook", cover: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&q=80&w=400&h=600", note: "A love story that hits every single time." },
  { title: "Manchester by the Sea", cover: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&q=80&w=400&h=600", note: "Grief portrayed with brutal honesty." },
  { title: "Good Will Hunting", cover: "https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?auto=format&fit=crop&q=80&w=400&h=600", note: "It's not your fault. One of the GOAT performances." },
  { title: "Me Before You", cover: "https://images.unsplash.com/photo-1518621736915-f3b1c41bfd00?auto=format&fit=crop&q=80&w=400&h=600", note: "A beautiful and devastating story about living fully." },
  { title: "Interstellar", cover: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&q=80&w=400&h=600", note: "Space, time, love — Nolan at his most ambitious." }
];

const series = [
  { title: "Shameless", cover: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?auto=format&fit=crop&q=80&w=400&h=600", note: "11 seasons of gloriously chaotic family TV." },
  { title: "Suits", cover: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=400&h=600", note: "Sharp suits, sharper dialogue. Peak law-drama." },
  { title: "The Mentalist", cover: "https://goldendiscs.ie/products/the-mentalist-the-complete-series-bruno-heller-dvd?srsltid=AfmBOoroLFYI7sNTpwE_UEbBX0B4R6SF7Y9ll7ZA9oE0e8ptUCBHzuhG", note: "Patrick Jane and his infuriatingly clever mind." },
  { title: "The Pitt", cover: "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?auto=format&fit=crop&q=80&w=400&h=600", note: "Intense medical drama with real-time pacing." },
  { title: "Grey's Anatomy", cover: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&q=80&w=400&h=600", note: "The original hospital drama that refuses to die." }
];

const music = [
  {
    artist: "Joji",
    cover: "https://images.unsplash.com/photo-1619983081563-430f63602796?auto=format&fit=crop&q=80&w=200&h=200",
    tracks: [
      { title: "Die For You" },
      { title: "Sanctuary" },
      { title: "Past won't leave my bed" },
      { title: "Glimpse of Us" },
      { title: "Like You Do" }
    ]
  },
  {
    artist: "Daniel Caesar",
    cover: "https://images.unsplash.com/photo-1493225457124-a1a2a5f5f994?auto=format&fit=crop&q=80&w=200&h=200",
    tracks: [
      { title: "Cyanide" },
      { title: "Moon" },
      { title: "Superposition" },
      { title: "Disillusioned" },
      { title: "Valentina" }
    ]
  },
  {
    artist: "Arctic Monkeys",
    cover: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&q=80&w=200&h=200",
    tracks: [
      { title: "Suck It and See" },
      { title: "Baby I'm Yours" },
      { title: "Arabella" },
      { title: "Snap Out of It" },
      { title: "Cornerstone" }
    ]
  },
  {
    artist: "Luke Chiang",
    cover: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=200&h=200",
    tracks: [
      { title: "Better" },
      { title: "Static" },
      { title: "terrible4u" },
      { title: "Good Company" },
      { title: "Heaven" }
    ]
  },
  {
    artist: "Niki",
    cover: "https://images.unsplash.com/photo-1559181567-c3190ca9d5db?auto=format&fit=crop&q=80&w=200&h=200",
    tracks: [
      { title: "Oceans & Engines", highlight: true },
      { title: "Split" },
      { title: "Urs" },
      { title: "Anaheim" },
      { title: "Autumn" }
    ]
  }
];

const projects = [
  {
    title: "Comic Portfolio",
    description: "This very site — a static portfolio with a sleek streaming-app aesthetic, built in vanilla HTML/CSS/JS.",
    tags: ["HTML", "CSS", "JavaScript"],
    repo: "#",
    demo: "#"
  },
  {
    title: "Task CLI",
    description: "Command line todo tracker built in Go with local file persistence.",
    tags: ["Go", "CLI"],
    repo: "#",
    demo: "#"
  },
  {
    title: "Weather Dashboard",
    description: "Live weather app powered by the Open-Meteo API with a clean, minimal UI.",
    tags: ["React", "API", "CSS"],
    repo: "#",
    demo: "#"
  }
];

const photography = [
  "https://images.unsplash.com/photo-1551334787-21e6bd3ab135?auto=format&fit=crop&q=80&w=900",
  "https://images.unsplash.com/photo-1506744626753-1fa28f67c9fe?auto=format&fit=crop&q=80&w=900",
  "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&q=80&w=900",
  "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&q=80&w=900",
  "https://images.unsplash.com/photo-1511884642898-4c92249e20b6?auto=format&fit=crop&q=80&w=900",
  "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&q=80&w=900",
  "https://images.unsplash.com/photo-1465101162946-4377e57745c3?auto=format&fit=crop&q=80&w=900",
  "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&q=80&w=900"
];

/* =====================
   INLINE SVG ICONS
   ===================== */
const chevronSVG = `<svg class="chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`;
const musicSVG = `<svg class="track-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>`;
const searchSVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`;
const closeSVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
const gitSVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="18" r="3"/><circle cx="6" cy="6" r="3"/><circle cx="18" cy="6" r="3"/><path d="M18 9v1a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V9"/><line x1="12" y1="12" x2="12" y2="15"/></svg>`;
const demoSVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`;

/* =====================
   RENDERERS
   ===================== */
function renderMediaCards(arr, containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = arr.map(item => `
    <div class="media-card">
      <div class="media-card-poster">
        <img src="${item.cover}" alt="${item.title}" loading="lazy">
        <div class="media-card-overlay">
          <p class="media-card-note">${item.note}</p>
        </div>
      </div>
      <div class="media-card-body">
        <div class="media-card-title">${item.title}</div>
      </div>
    </div>
  `).join('');
}

function renderProjects() {
  const el = document.getElementById('projects-grid');
  if (!el) return;
  el.innerHTML = projects.map(p => `
    <div class="project-card">
      <h3>${p.title}</h3>
      <p>${p.description}</p>
      <div class="tag-group">
        ${p.tags.map(t => `<span class="tag">${t}</span>`).join('')}
      </div>
      <div class="project-links">
        <a href="${p.repo}" class="btn btn-ghost" target="_blank">${gitSVG} Repo</a>
        <a href="${p.demo}" class="btn btn-primary" target="_blank">${demoSVG} Live</a>
      </div>
    </div>
  `).join('');
}

function renderMusic() {
  const el = document.getElementById('music-container');
  if (!el) return;
  el.innerHTML = music.map((a, i) => `
    <div class="artist-card" id="artist-${i}">
      <div class="artist-trigger"
        role="button" tabindex="0" aria-expanded="false"
        onclick="toggleArtist(${i})"
        onkeydown="if(event.key==='Enter'||event.key===' ')toggleArtist(${i})">
        <div class="artist-cover-wrap">
          <img src="${a.cover}" alt="${a.artist}" loading="lazy">
          <div class="artist-cover-overlay"></div>
        </div>
        <div class="artist-info">
          <div class="artist-name">${a.artist}</div>
          <div class="artist-sub">${a.tracks.length} tracks</div>
        </div>
        ${chevronSVG}
      </div>
      <div class="tracklist-panel">
        <ol class="tracklist">
          ${a.tracks.map((t, ti) => `
            <li>
              <span class="track-num">${ti + 1}</span>
              <span class="track-name ${t.highlight ? 'highlight' : ''}">${t.title}</span>
              ${musicSVG}
            </li>
          `).join('')}
        </ol>
      </div>
    </div>
  `).join('');
}

function toggleArtist(idx) {
  const card = document.getElementById(`artist-${idx}`);
  const isOpen = card.classList.contains('open');
  document.querySelectorAll('.artist-card.open').forEach(c => {
    c.classList.remove('open');
    c.querySelector('.artist-trigger').setAttribute('aria-expanded', 'false');
  });
  if (!isOpen) {
    card.classList.add('open');
    card.querySelector('.artist-trigger').setAttribute('aria-expanded', 'true');
  }
}

function renderPhotography() {
  const el = document.getElementById('photo-grid');
  if (!el) return;
  el.innerHTML = photography.map((src, i) => `
    <div class="photo-item" onclick="openLightbox('${src}')"
      role="button" tabindex="0" aria-label="Open photo ${i + 1}"
      onkeydown="if(event.key==='Enter')openLightbox('${src}')">
      <img src="${src}" alt="Photo ${i + 1}" loading="lazy">
      <div class="photo-zoom-overlay">
        <div class="zoom-icon">${searchSVG}</div>
      </div>
    </div>
  `).join('');
}

function openLightbox(src) {
  let lb = document.getElementById('lightbox');
  if (!lb) {
    lb = document.createElement('div');
    lb.id = 'lightbox';
    lb.className = 'lightbox';
    lb.innerHTML = `
      <button class="lightbox-close" onclick="closeLightbox()" aria-label="Close">${closeSVG}</button>
      <img src="" alt="Full size">
    `;
    lb.addEventListener('click', e => { if (e.target === lb) closeLightbox(); });
    document.body.appendChild(lb);
  }
  lb.querySelector('img').src = src;
  lb.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeLightbox() {
  document.getElementById('lightbox')?.classList.remove('active');
  document.body.style.overflow = '';
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });

/* =====================
   AUTO-INIT
   ===================== */
document.addEventListener('DOMContentLoaded', () => {
  renderMediaCards(movies, 'movies-grid');
  renderMediaCards(series, 'series-grid');
  renderProjects();
  renderMusic();
  renderPhotography();
});
